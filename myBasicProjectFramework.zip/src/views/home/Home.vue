<template>
<!-- 书城首页 -->
<div class="Home-Wrap">
  
</div>
</template>

<style lang="scss">
</style>

<script>
export default {
  name: "home",
  data() {
    return {};
  }
};
</script>
