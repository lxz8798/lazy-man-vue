/**
 * 把模块化的接口文件统一并暴露出去
 * @author 李啸竹
 */
import example from "./example";

export default {
    example
}