/* eslint-disable */
/**
 * 定义常量,使用常替代mutation事件类型，VUE推荐大写
 * @DETAIL_COUNT 测试用
 * @author 李啸竹
 */
const DETAIL_COUNT = 'DETAIL_COUNT'
const INCREMENT = 'INCREMENT'
const DECREMENT = 'DECREMENT'

export default {
    DETAIL_COUNT,INCREMENT,DECREMENT
}